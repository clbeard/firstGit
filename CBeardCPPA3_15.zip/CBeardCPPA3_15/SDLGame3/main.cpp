#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <iostream>
#include <string>

using namespace std;


//bool to maintain program loop
bool quit;
//delta time inti- for fram rate
float deltaTime = 0.0f;
int thisTime = 0;
int lastTime = 0;



//controlled by keypress not deltatime
int playerMovement = 71;

//create rectangles for player position
SDL_Rect playerPos;






int main(int argc, char* args[])
{



	SDL_Window* window;			//declare a pointer


	//create a renderer variable
	SDL_Renderer* renderer = NULL;

	SDL_Init(SDL_INIT_EVERYTHING); //initialize sdl2

	//create an application with the following setttings
	window = SDL_CreateWindow(
		"Dungeon Crawler",
		SDL_WINDOWPOS_UNDEFINED,//inital x position
		SDL_WINDOWPOS_UNDEFINED,
		642, //width in px
		358,	//height
		SDL_WINDOW_OPENGL

	);

	//check that the window was successfully created
	if (window == NULL)
	{
		//in the case that the winod couldnt be opened
		printf("Could not create window: %s/n", SDL_GetError());
		return 1;
	}

	//create renderer
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	//background image
	//create
	SDL_Surface* surface = IMG_Load("./Assets/level.png");

	//create bkgd texture
	SDL_Texture* bkgd;

	//place surface into the texture
	bkgd = SDL_CreateTextureFromSurface(renderer, surface);

	//free the surface
	SDL_FreeSurface(surface);

	//create rectangle for the menu gaphcis
	SDL_Rect bkgdPos;

	//set bkgd x,y,width,height
	bkgdPos.x = 0;
	bkgdPos.y = 0;
	bkgdPos.w = 642;
	bkgdPos.h = 358;



	//end background creation end

	//player image ---create
	//create sdl surface
	surface = IMG_Load("./Assets/Player.png");

	//create bkgd texture
	SDL_Texture* player;

	//place surface into the texture
	player = SDL_CreateTextureFromSurface(renderer, surface);

	//free the surface
	SDL_FreeSurface(surface);



	//set bkgdpos x ,y,width,height
	playerPos.x = 291;
	playerPos.y = 291;
	playerPos.w = 59;
	playerPos.h = 59;


	//SDL event to handle input
	SDL_Event event;

	//maze settings - width and height
	const int mazeWidth = 9;
	const int mazeHeight = 5;

	//create the array for the maze "o" = open space, "W" = well,"P" = player
	string maze[mazeHeight][mazeWidth] =
	{
		{"O","O","O","O","O","O","O","O","O"},
		{"O","W","O","W","W","W","O","W","O"},
		{"O","O","O","O","W","O","O","O","O"},
		{"O","W","O","W","W","W","O","W","O"},
		{"O","O","O","O","P","O","O","O","O"}
	};

	//player staring position in the maze row 5 column 5 = maze[4][4]
	int playerHorizontal = 4;
	int playerVertical = 4;

	//basic program loop
	while (!quit)
	{


		//create deltaTime
		thisTime = SDL_GetTicks();
		deltaTime = (float)(thisTime - lastTime) / 1000;
		lastTime = thisTime;

		//check for input
		if (SDL_PollEvent(&event))
		{

			//close windows by windwos x button
			if (event.type == SDL_QUIT)
			{
				quit = true;
			}

			switch (event.type)
			{

				//look for keypress
				case SDL_KEYUP:

				//check the sdl key values
				switch (event.key.keysym.sym)
				{
					case SDLK_RIGHT://move right

					//chcking if players horizontal position is within the limit
					if ((playerHorizontal + 1) < mazeWidth)
					{
						//if the spot to the right is open =="o"
						if (maze[playerVertical][playerHorizontal + 1] == "O")
						{

						//move the player in the maze array - set the future spot to "P"
						maze[playerVertical][playerHorizontal + 1] = "P";

						//move the spot in the maze array - set the players old spot to "o"
						maze[playerVertical][playerHorizontal] = "O";
				
						//increase the horizontal movement tracking number by one 
						playerHorizontal += 1;

						//increase the player position x by 71 - move right
						playerPos.x += playerMovement;

						}
						
					}

					break;


					case SDLK_LEFT://move left
					//chcking if players horizontal position is within the limit
					if ((playerHorizontal - 1) >= 0)
					{
						//if the spot to the right is open =="o"
						if (maze[playerVertical][playerHorizontal - 1] == "O")
						{
							//move the player in the maze array - set the future spot to "P"
							maze[playerVertical][playerHorizontal - 1] = "P";

							//move the spot in the maze array - set the players old spot to "o"
							maze[playerVertical][playerHorizontal] = "O";

							//increase the horizontal movement tracking number by one 
							playerHorizontal -= 1;

							//decrease the player position x by 71 - move left
							playerPos.x -= playerMovement;

						}
					}

					break;

					case SDLK_UP://move up
					//chcking if players vertical position is within the limit
					if ((playerVertical - 1) >= 0)
					{


						//if the spot to the top is open =="o"
						if (maze[playerVertical - 1][playerHorizontal] == "O")
						{

							//move the player in the maze array - set the future spot to "P"
							maze[playerVertical-1][playerHorizontal] = "P";

							//move the spot in the maze array - set the players old spot to "o"
							maze[playerVertical][playerHorizontal] = "O";
							//increase the vertiacl movement tracking number by one 
							playerVertical -= 1;
							//increase the player position y by 71 - move up
							playerPos.y -= playerMovement;
						}
					}
					break;

					case SDLK_DOWN://move down

					//chcking if players vertical position is within the limit
					if ((playerVertical + 1) < mazeHeight)
					{
						//if the spot to the top is open =="o"
						if (maze[playerVertical + 1][playerHorizontal] == "O")
						{
							//move the player in the maze array - set the future spot to "P"
							maze[playerVertical+1][playerHorizontal] = "P";

							//move the spot in the maze array - set the players old spot to "o"
							maze[playerVertical][playerHorizontal] = "O";
							//increase the vertiacl movement tracking number by one 
							playerVertical += 1;
							//decrease the player position y by 71 - move down
							playerPos.y += playerMovement;
						}

					}
					break;

				default:
					break;

				}

			}


		}

			//start draw
			//clear old buffer
			SDL_RenderClear(renderer);

			//draw bkgd
			SDL_RenderCopy(renderer, bkgd, NULL, &bkgdPos);


			//draw player
			SDL_RenderCopy(renderer, player, NULL, &playerPos);

			//draw new info to the screen'
			SDL_RenderPresent(renderer);
			//end draw

		
	}//end program loop

		//close and destroy the window
		SDL_DestroyWindow(window);

		//clean up
		SDL_Quit();

		return 0;
}