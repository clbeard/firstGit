#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <stdio.h>
#include <iostream>
#include <string>

using namespace std;

//boolean to maintain game loop
bool quit = false;




//parameters for sdl
int main(int argc,char* argv[])
{

	SDL_Window* window;				//declaring pointer

	//creating a renderer for graphics
	SDL_Renderer* renderer = NULL;

	SDL_Init(SDL_INIT_EVERYTHING); //initialize SDL2

	//creating an application window with the following settings
	window = SDL_CreateWindow(
		"Space Game",				//window title
		SDL_WINDOWPOS_UNDEFINED,	//initial x position
		SDL_WINDOWPOS_UNDEFINED,	//intital y position
		1024, //width in pixels
		768, //height in pixels
		SDL_WINDOW_OPENGL    //flags see below

	);


	//check to see the window was created succesfully
	if (window == NULL)
	{
		printf("Could not create window: %s\n", SDL_GetError());
		return 1;
	}


	//create renderer
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	//background image -- create

	//create a SDL surface
	SDL_Surface* surface = IMG_Load("./Assets/bkgd.png");

	//create texture
	SDL_Texture* bkgd;

	//place surface into the texture
	bkgd = SDL_CreateTextureFromSurface(renderer, surface);

	//free the surface
	SDL_FreeSurface(surface);

	//create rectangle graphics for background postion
	SDL_Rect bkgdPos;

	//set bkgdpos x,y,width,.height
	bkgdPos.x = 0;
	bkgdPos.y = 0;
	bkgdPos.w = 1024;
	bkgdPos.h = 768;

	//background image -- create Find

	//player image create


	//create sdl surface
	surface = IMG_Load("./Assets/player.png");

	//create bkgd texture
	SDL_Texture* player;

	//place surface into the texture
	player = SDL_CreateTextureFromSurface(renderer, surface);

	//free the surface
	SDL_FreeSurface(surface);

	//create rectangle graphics for player pos
	SDL_Rect playerPos;

	//set bkgdpos x ,y,width,height
	playerPos.x = 500;
	playerPos.y = 700;
	playerPos.w = 119;//119
	playerPos.h = 38;//38

	//player image -- create end


	//sdl event to handle input
	SDL_Event event;


	//basic game loop
	while (!quit)
	{
		//check for input
		if (SDL_PollEvent(&event))
		{

			//close windows by windwos x button
			if (event.type == SDL_QUIT)
			{
				quit = true;
			}
			

		}
		//draw **********************************

		//clear the old buffer
		SDL_RenderClear(renderer);

		//prepare to draw bkgd
		SDL_RenderCopy(renderer, bkgd, NULL, &bkgdPos);

		//prepare to draw bkgd
		SDL_RenderCopy(renderer, player, NULL, &playerPos);

		//draw new info to the screen
		SDL_RenderPresent(renderer);

		//end draw**********************

	}//ends game loop

	//close and destroy the window
	SDL_DestroyWindow(window);

	//clean up
	SDL_Quit();

	return 0;


}

